import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;

class CreatureGUI {
    private JFrame frame;
    private JTable table;
    private JTextField filterText;
    private DefaultTableModel model;
    private TableRowSorter<DefaultTableModel> sorter;

    public CreatureGUI(List<MagicalCreature> creatures) {
        frame = new JFrame("Magical Creatures");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        String[] columnNames = {"Name", "Type", "Potion Usage", "Date Found", "Wizard Name", "Endangered"};
        model = new DefaultTableModel(columnNames, 0);
        sorter = new TableRowSorter<>(model);

        for (MagicalCreature creature : creatures) {
            Object[] row = new Object[6];
            row[0] = creature.getName();
            row[1] = creature.getType().toString();
            row[2] = creature.getPotionUsage();
            row[3] = creature.getDateFound().toString();
            row[4] = creature.getWizardName();
            row[5] = creature.isEndangered() ? "Yes" : "No";
            model.addRow(row);
        }

        table = new JTable(model);
        table.setRowSorter(sorter);

        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Filter:");
        panel.add(label, BorderLayout.WEST);
        filterText = new JTextField(30);
        panel.add(filterText, BorderLayout.CENTER);
        frame.add(panel, BorderLayout.NORTH);

        filterText.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                newFilter();
            }
            public void insertUpdate(DocumentEvent e) {
                newFilter();
            }
            public void removeUpdate(DocumentEvent e) {
                newFilter();
            }
        });

        frame.setVisible(true);
    }

    private void newFilter() {
        RowFilter<DefaultTableModel, Object> rf = null;
        try {
            rf = RowFilter.regexFilter(filterText.getText(), 0);
        } catch (java.util.regex.PatternSyntaxException e) {
            return;
        }
        sorter.setRowFilter(rf);
    }
}
