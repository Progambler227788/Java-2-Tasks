import java.time.LocalDate;

class MagicalCreature {
    private String name;
    private Type type;
    private String potionUsage;
    private LocalDate dateFound;
    private String wizardName;
    private boolean endangered;

    public enum Type {
        GOOD, NEUTRAL, MALICIOUS
    }

    public MagicalCreature(String name, Type type, String potionUsage, LocalDate dateFound, String wizardName, boolean endangered) {
        this.name = name;
        this.type = type;
        this.potionUsage = potionUsage;
        this.dateFound = dateFound;
        this.wizardName = wizardName;
        this.endangered = endangered;
    }

    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }

    public String getPotionUsage() {
        return potionUsage;
    }

    public LocalDate getDateFound() {
        return dateFound;
    }

    public String getWizardName() {
        return wizardName;
    }

    public boolean isEndangered() {
        return endangered;
    }

    @Override
    public String toString() {
        return "MagicalCreature{" +
                "name='" + name + '\'' +
                ", type=" + type +
                ", potionUsage='" + potionUsage + '\'' +
                ", dateFound=" + dateFound +
                ", wizardName='" + wizardName + '\'' +
                ", endangered=" + endangered +
                '}';
    }
}
