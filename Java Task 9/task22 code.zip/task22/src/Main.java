import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/creature", "root", "");
            List<MagicalCreature> creatures = getAllCreaturesFromDatabase(connection);
            new CreatureGUI(creatures);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static List<MagicalCreature> getAllCreaturesFromDatabase(Connection connection) throws SQLException {
        List<MagicalCreature> creatures = new ArrayList<>();
        String sql = "SELECT * FROM creatures";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                MagicalCreature.Type type = MagicalCreature.Type.valueOf(resultSet.getString("type"));
                String potionUsage = resultSet.getString("potion_usage");
                LocalDate dateFound = resultSet.getDate("date_found").toLocalDate();
                String wizardName = resultSet.getString("wizard_name");
                boolean endangered = resultSet.getBoolean("endangered");
                MagicalCreature creature = new MagicalCreature(name, type, potionUsage, dateFound, wizardName, endangered);
                creatures.add(creature);
            }
        }
        return creatures;
    }
}


