package org.example.management;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;

public class PointsManagerController {
    @FXML
    private TextField addTeamNamefield;

    @FXML
    private TextField addTeamMemberName;

    @FXML
    private TextField teamNameforEvent;

    @FXML
    private TextField QuizEventNumber;

    @FXML
    private TextArea displayTextArea;

    @FXML
    private TextArea eventTextArea;
    @FXML
    private TextField teamNameToAddPoints;

    @FXML
    private TextField pointsField;

    @FXML
    private TextArea displayPointsTextArea;
    @FXML
    private Button saveandQuitButton;
    private static int lastBookingId = 0;

    @FXML
    void addTeam(ActionEvent event) {
        String teamName = addTeamNamefield.getText().trim();
        String memberName = addTeamMemberName.getText().trim();

        if (!teamName.isEmpty() && !memberName.isEmpty()) {
            ArrayList<Team> teams = readTeamsFromFile(); // Read existing teams from file

            // Check if the team name already exists
            boolean teamExists = false;
            for (Team team : teams) {
                if (team.getName().equalsIgnoreCase(teamName)) {
                    // If the team already exists, add the member to it
                    if (team.getMembers().size() < 6) { // Check if maximum members limit is not reached
                        team.getMembers().add(memberName);
                        teamExists = true;
                        break;
                    } else {
                        System.out.println("Maximum members limit reached for the team.");
                        return; // Stop further execution
                    }
                }
            }

            // If the team doesn't exist, create a new team
            if (!teamExists) {
                ArrayList<String> members = new ArrayList<>();
                members.add(memberName);
                Team newTeam = new Team(teamName, members);
                teams.add(newTeam);
            }

            // Write updated team data to teams.txt file
            writeTeamsToFile(teams);

            // Clear text fields after adding team
            addTeamNamefield.clear();
            addTeamMemberName.clear();
        } else {
            // Handle error if team name or member name is empty
            System.out.println("Team name and member name cannot be empty.");
        }
    }

    private ArrayList<Team> readTeamsFromFile() {
        ArrayList<Team> teams = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String teamName = parts[0].trim();
                ArrayList<String> members = new ArrayList<>();
                for (int i = 1; i < parts.length; i++) {
                    members.add(parts[i].trim());
                }
                Team team = new Team(teamName, members);
                teams.add(team);

                // Print team details for debugging
                System.out.println("Team Name: " + teamName);
                System.out.println("Members: " + members);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return teams;
    }



    private void writeTeamsToFile(ArrayList<Team> teams) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("teams.txt"))) {
            for (Team team : teams) {
                writer.write(team.getName());
                writer.write(","); // Add comma after team name
                for (String member : team.getMembers()) {
                    writer.write(member + ","); // Add comma after each member
                }
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @FXML
    void displayTeams(ActionEvent event) {
        displayTextArea.clear(); // Clear the text area before displaying teams

        try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
            String line;

            // Display header
            displayTextArea.appendText(String.format("%-15s %s\n", "Team", "Members"));
            displayTextArea.appendText("\n");

            // Read each line from the file
            while ((line = reader.readLine()) != null) {
                // Check if the line contains points information
                if (line.contains(", Points ")) {
                    continue; // Skip this line
                }

                String[] parts = line.split(","); // Split the line using comma as delimiter

                // Check if the line contains team information
                if (parts.length > 1) {
                    String teamName = parts[0].trim();
                    String[] members = new String[parts.length - 1]; // Array to store members

                    // Extract member names
                    for (int i = 1; i < parts.length; i++) {
                        members[i - 1] = parts[i].trim();
                    }

                    // Display team and its members
                    String formattedTeam = String.format("%-15s %s\n", teamName, String.join(", ", members));
                    displayTextArea.appendText(formattedTeam);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    // Method to delete a team
    @FXML
    void deleteTeam(ActionEvent event) {
        String teamNameToDelete = addTeamNamefield.getText().trim();

        if (!teamNameToDelete.isEmpty()) {
            ArrayList<String> teams = new ArrayList<>();

            try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    // Split the line into team name, members, and points
                    String[] parts = line.split(",");
                    String teamName = parts[0].trim();

                    // If the team name matches the one to be deleted, skip this line
                    if (!teamName.equals(teamNameToDelete)) {
                        teams.add(line);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Write the updated list of teams back to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("teams.txt"))) {
                for (String team : teams) {
                    writer.write(team);
                    writer.newLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Clear the text field after deleting team
            addTeamNamefield.clear();
        } else {
            System.out.println("Please enter the name of the team to delete.");
        }
    }

    @FXML
    void showAllEvents(ActionEvent event) {
        eventTextArea.clear(); // Clear the text area before displaying events

        // Initialize events if not already initialized
        if (QuizEvent.getAvailableEvents().isEmpty()) {
            QuizEvent.initializeEvents();
        }

        // Get the list of available events
        ArrayList<QuizEvent> events = QuizEvent.getAvailableEvents();

        // Display header
        eventTextArea.appendText(String.format("%-10s %-25s %s\n", "", "Available Quiz Events", ""));
        eventTextArea.appendText("----------------------------------------------------------\n");

        // Check if there are no events available
        if (events.isEmpty()) {
            eventTextArea.appendText("No events available.");
        } else {
            // Display each event number, name, and date
            for (int i = 0; i < events.size(); i++) {
                QuizEvent quizEvent = events.get(i);
                String formattedEvent = String.format("%-10d %-25s %s\n", i + 1, quizEvent.getName(), quizEvent.getDate());
                eventTextArea.appendText(formattedEvent);
            }
        }
    }
    @FXML
    void bookEvent(ActionEvent event) {
        String teamName = teamNameforEvent.getText().trim();
        String eventNumberStr = QuizEventNumber.getText().trim();

        // Check if the team name and event number are not empty
        if (!teamName.isEmpty() && !eventNumberStr.isEmpty()) {
            try {
                int eventNumber = Integer.parseInt(eventNumberStr);

                // Check if the entered team name exists
                ArrayList<Team> teams = readTeamsFromFile();
                boolean teamExists = false;
                for (Team team : teams) {
                    if (team.getName().equalsIgnoreCase(teamName)) {
                        teamExists = true;
                        break;
                    }
                }

                if (teamExists) {
                    // Check if the entered event number is valid
                    ArrayList<QuizEvent> availableEvents = QuizEvent.getAvailableEvents();
                    if (eventNumber >= 1 && eventNumber <= availableEvents.size()) {
                        QuizEvent selectedEvent = availableEvents.get(eventNumber - 1); // Adjust for 0-based index
                        String eventName = selectedEvent.getName();

                        try (BufferedWriter writer = new BufferedWriter(new FileWriter("teams.txt", true))) {
                            // Write the booking entry to the file
                            writer.write(teamName + "|" + eventName); // Use "|" as the delimiter
                            writer.newLine();
                            System.out.println("Event booked successfully for team: " + teamName);
                        } catch (IOException e) {
                            System.out.println("Failed to book the event. Please try again.");
                            e.printStackTrace();
                        }

                        // Clear text fields after successful booking
                        teamNameforEvent.clear();
                        QuizEventNumber.clear();
                    } else {
                        System.out.println("Invalid event number. Please enter a number between 1 and " + availableEvents.size() + ".");
                    }
                } else {
                    System.out.println("Team does not exist. Please enter a valid team name.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid event number. Please enter a valid number.");
            }
        } else {
            System.out.println("Team name and event number cannot be empty.");
        }
    }



    // Method to generate a unique booking ID
    private int generateBookingId() {
        // You can implement your own logic to generate a unique ID here
        // For simplicity, let's use a simple counter starting from 1
        return ++lastBookingId;
    }


    @FXML
    void displayBookings(ActionEvent event) {
        eventTextArea.clear(); // Clear the text area before displaying bookings

        boolean hasBookings = false; // Flag to track if any bookings are found

        try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
            String line;

            // Read each line from the file
            while ((line = reader.readLine()) != null) {
                // Check if the line represents a booking
                if (line.contains("|")) {
                    String[] parts = line.split("\\|"); // Use "|" as the delimiter

                    if (parts.length == 2) {
                        String teamName = parts[0].trim();
                        String eventName = parts[1].trim();

                        if (!hasBookings) {
                            eventTextArea.appendText("Booking Report\n");
                            eventTextArea.appendText("------------------------------\n");
                            hasBookings = true;
                        }

                        eventTextArea.appendText("Team: " + teamName + "\n");
                        eventTextArea.appendText("Booked Event: " + eventName + "\n");
                        eventTextArea.appendText("------------------------------\n");
                    } else {
                        System.out.println("Invalid booking format: " + line);
                    }
                }
            }

            // If no bookings found, display a message
            if (!hasBookings) {
                eventTextArea.appendText("No bookings found.\n");
                eventTextArea.appendText("------------------------------\n");
            }
        } catch (IOException e) {
            // Print any exceptions that occur while reading from the file
            e.printStackTrace();
        }
    }




    @FXML
    void deleteBooking(ActionEvent event) {
        String teamNameToDelete = teamNameforEvent.getText().trim();

        if (!teamNameToDelete.isEmpty()) {
            try {
                // Read all bookings from the file
                ArrayList<String> bookings = new ArrayList<>();
                try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        // Check if the line contains a booking for the team to delete
                        if (!line.startsWith(teamNameToDelete + "|")) {
                            // Add the line to the list of bookings if it's not associated with the team to delete
                            bookings.add(line);
                        }
                    }
                }

                // Rewrite the updated list of bookings back to the file
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("teams.txt"))) {
                    for (String booking : bookings) {
                        writer.write(booking);
                        writer.newLine();
                    }
                }

                // Clear the text field after deleting bookings
                teamNameforEvent.clear();

                System.out.println("Bookings for team '" + teamNameToDelete + "' deleted successfully.");
            } catch (IOException e) {
                System.out.println("Failed to delete bookings.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Please enter the name of the team to delete its bookings.");
        }
    }
    @FXML
    void addPoints(ActionEvent event) {
        displayPointsTextArea.clear(); // Clear the text area before displaying the leaderboard

        String teamName = teamNameToAddPoints.getText().trim();
        String pointsStr = pointsField.getText().trim();

        // Check if both fields are not empty
        if (!teamName.isEmpty() && !pointsStr.isEmpty()) {
            try {
                int points = Integer.parseInt(pointsStr); // Parse points to an integer

                // Check if the team already exists in the file
                boolean teamExists = false;
                ArrayList<String> updatedLines = new ArrayList<>();
                try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.split(", Points ");
                        if (parts.length == 2 && parts[0].trim().equalsIgnoreCase(teamName)) {
                            int existingPoints = Integer.parseInt(parts[1].trim());
                            existingPoints += points; // Sum up the existing points with the new points
                            updatedLines.add(parts[0].trim() + ", Points " + existingPoints);
                            teamExists = true;
                        } else {
                            updatedLines.add(line);
                        }
                    }
                }

                // If the team doesn't exist, add it to the file with the new points
                if (!teamExists) {
                    updatedLines.add(teamName + ", Points " + points);
                }

                // Write the updated lines back to the file
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("teams.txt"))) {
                    for (String line : updatedLines) {
                        writer.write(line);
                        writer.newLine();
                    }
                }

                displayPointsTextArea.appendText(points + " points added to team " + teamName + "\n");
            } catch (NumberFormatException e) {
                displayPointsTextArea.appendText("Invalid points value. Please enter a valid number.\n");
            } catch (IOException e) {
                displayPointsTextArea.appendText("Failed to update points for team " + teamName + ". Please try again.\n");
                e.printStackTrace();
            }
        } else {
            displayPointsTextArea.appendText("Please enter both team name and points.\n");
        }
        teamNameToAddPoints.clear();
        pointsField.clear();
    }

    private void writePointsToFile(String teamName, int points) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("teams.txt", true))) {
            String formattedEntry = String.format("%s, Points %d", teamName, points);
            writer.write(formattedEntry);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void displayLeaderboard(ActionEvent event) {
        displayPointsTextArea.clear(); // Clear the text area before displaying the leaderboard

        // Create an ArrayList to store team names and their points
        ArrayList<String> teamsData = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
            String line;

            // Read each line from the file
            while ((line = reader.readLine()) != null) {
                // Split the line into team name and points
                String[] parts = line.split(", Points ");
                if (parts.length == 2) {
                    String teamName = parts[0].trim();
                    int points = Integer.parseInt(parts[1].trim());

                    // Format the team data as "TeamName,Points" and add it to the ArrayList
                    String teamData = String.format("%s,%d", teamName, points);
                    teamsData.add(teamData);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Sort the ArrayList based on points (descending order)
        teamsData.sort((team1, team2) -> {
            int points1 = Integer.parseInt(team1.split(",")[1]);
            int points2 = Integer.parseInt(team2.split(",")[1]);
            return Integer.compare(points2, points1);
        });

        // Display header
        displayPointsTextArea.appendText(String.format("%-15s %s\n", "Team", "Points"));
        displayPointsTextArea.appendText("\n");

        // Display teams and their points
        for (String teamData : teamsData) {
            // Split the team data back into team name and points
            String[] parts = teamData.split(",");
            String teamName = parts[0];
            int points = Integer.parseInt(parts[1]);

            // Display team name and points
            String formattedTeam = String.format("%-15s %d\n", teamName, points);
            displayPointsTextArea.appendText(formattedTeam);
        }
    }



    @FXML
    void saveAndQuit(ActionEvent event) {


        // Close the application
        Platform.exit();
    }



}
