package Persistence;

import Bussiness.Movie;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializer;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MoviesDAO {
    private static final String FILE_PATH = "movies.json";
    private Gson gson;

    public MoviesDAO() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(new TypeToken<List<String>>() {}.getType(), (JsonDeserializer<List<String>>) (json, typeOfT, context) -> {
            List<String> genres = new ArrayList<>();
            if (json.isJsonArray()) {
                json.getAsJsonArray().forEach(element -> genres.add(element.getAsString()));
            } else if (json.isJsonPrimitive()) {
                genres.add(json.getAsString());
            }
            return genres;
        });
        this.gson = gsonBuilder.create();
    }

    public List<Movie> loadMovies() {
        try (Reader reader = new FileReader(FILE_PATH)) {
            return gson.fromJson(reader, new TypeToken<List<Movie>>() {}.getType());
        } catch (FileNotFoundException e) {
            System.out.println("movies.json file not found, returning an empty list.");
            return List.of();
        } catch (IOException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public void saveMovies(List<Movie> movies) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(movies, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
