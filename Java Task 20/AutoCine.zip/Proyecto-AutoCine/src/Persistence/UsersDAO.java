package Persistence;

import Bussiness.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.util.List;

public class UsersDAO {
    private static final String FILE_PATH = "users.json";
    private Gson gson;

    public UsersDAO() {
        this.gson = new Gson();
    }

    public List<User> loadUsers() {
        try (Reader reader = new FileReader(FILE_PATH)) {
            return gson.fromJson(reader, new TypeToken<List<User>>() {}.getType());
        } catch (FileNotFoundException e) {
            System.out.println("users.json file not found, returning an empty list.");
            return List.of();
        } catch (IOException e) {
            e.printStackTrace();
            return List.of();
        }
    }

    public void saveUsers(List<User> users) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(users, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
