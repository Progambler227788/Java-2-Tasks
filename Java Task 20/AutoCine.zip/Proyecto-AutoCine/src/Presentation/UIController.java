package Presentation;

import Bussiness.User;
import Bussiness.UserManager;

import java.util.Scanner;

public class UIController {
    private UserManager userManager;
    private Scanner scanner;
    private MenuAdmin menuAdmin;
    private MenuPrincipal menuPrincipal;

    public UIController() {
        this.userManager = new UserManager();
        this.scanner = new Scanner(System.in);
        this.menuAdmin = new MenuAdmin();
        this.menuPrincipal = new MenuPrincipal();
    }

    public void start() {
        while (true) {
            System.out.println("Welcome to Automatic Cinema!");
            System.out.println("(L) Login");
            System.out.println("(R) Register");
            System.out.print("Choose an option: ");
            String option = scanner.nextLine();

            if (option.equalsIgnoreCase("L")) {
                login();
            } else if (option.equalsIgnoreCase("R")) {
                register();
            } else {
                System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void login() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        User user = userManager.getAllUsers().stream()
                .filter(u -> u.getUsername().equals(username) && u.getPassword().equals(password))
                .findFirst()
                .orElse(null);

        if (user != null) {
            switch (user.getRole()) {
                case "admin":
                    System.out.println("Administrator login correct!");
                    menuAdmin.showMenu();
                    break;
                case "manager":
                    System.out.println("Manager login correct!");
                    menuAdmin.showMenu();
                    break;
                case "user":
                    System.out.println("User login correct!");
                    menuPrincipal.showMenu();
                    break;
                default:
                    System.out.println("Unknown role.");
            }
        } else {
            System.out.println("Incorrect name or password.");
        }
    }

    private void register() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.print("Role (user/manager): ");
        String role = scanner.nextLine();

        System.out.println("Checking if the username already exists...");
        if (userManager.getAllUsers().stream().anyMatch(u -> u.getUsername().equals(username))) {
            System.out.println("Username already exists.");
        } else {
            System.out.println("Creating a new user...");
            User newUser = new User(username, password, role);
            userManager.addUser(newUser);
            System.out.println("New " + role + " created!");
        }
    }
}
