package Presentation;

import Bussiness.Product;
import Bussiness.ProductManager;
import Bussiness.Transaction;
import Bussiness.TransactionManager;
import Bussiness.User;
import Bussiness.UserManager;

import java.util.List;
import java.util.Scanner;

public class MenuAdmin {
    private ProductManager productManager;
    private TransactionManager transactionManager;
    private UserManager userManager;
    private Scanner scanner;

    public MenuAdmin() {
        this.productManager = new ProductManager();
        this.transactionManager = new TransactionManager();
        this.userManager = new UserManager();
        this.scanner = new Scanner(System.in);
    }

    public void showMenu() {
        while (true) {
            System.out.println("MENU:");
            System.out.println("1) Check stock");
            System.out.println("2) Replenish product");
            System.out.println("3) View economic history");
            System.out.println("4) Create a new manager");
            System.out.println("5) Exit");
            System.out.print("Opcio? ");
            int option = Integer.parseInt(scanner.nextLine());

            switch (option) {
                case 1:
                    checkStock();
                    break;
                case 2:
                    replenishProduct();
                    break;
                case 3:
                    viewEconomicHistory();
                    break;
                case 4:
                    createNewManager();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void checkStock() {
        List<Product> products = productManager.getAllProducts();
        System.out.println("STOCK");
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            System.out.printf("%d - %s - €%.2f/€%.2f (%d)\n", i + 1, product.getNom(), product.getPreuCompra(), product.getPreuVenta(), product.getQuantitat());
        }
    }

    private void replenishProduct() {
        checkStock();
        System.out.print("What product? ");
        int productIndex = Integer.parseInt(scanner.nextLine()) - 1;
        System.out.print("Amount? ");
        int amount = Integer.parseInt(scanner.nextLine());

        Product product = productManager.getAllProducts().get(productIndex);
        product.setQuantitat(product.getQuantitat() + amount);
        transactionManager.addTransaction(new Transaction("Restock", -product.getPreuCompra() * amount));
        productManager.updateProduct(product);

        System.out.printf("%d %s have been replenished for €%.2f\n", amount, product.getNom(), product.getPreuCompra() * amount);
    }

    private void viewEconomicHistory() {
        List<Transaction> transactions = transactionManager.getAllTransactions();
        System.out.println("HISTORY");
        transactions.stream().limit(20).forEach(t -> System.out.printf("%s - €%.2f\n", t.getType(), t.getAmount()));
        double balance = transactions.stream().mapToDouble(Transaction::getAmount).sum();
        System.out.printf("Current balance: €%.2f\n", balance);
    }

    private void createNewManager() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        User newManager = new User(username, password, "manager");
        userManager.addUser(newManager);
        System.out.println("New manager created!");
    }
}
