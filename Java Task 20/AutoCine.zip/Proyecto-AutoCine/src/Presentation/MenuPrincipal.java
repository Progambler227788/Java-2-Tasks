package Presentation;

import Bussiness.Movie;
import Bussiness.Product;
import Bussiness.ProductManager;
import Bussiness.MovieManager;
import Bussiness.Transaction;
import Bussiness.TransactionManager;

import java.util.List;
import java.util.Scanner;
import java.awt.Desktop;
import java.net.URI;

public class MenuPrincipal {
    private Scanner scanner;
    private ProductManager productManager;
    private MovieManager movieManager;
    private TransactionManager transactionManager;

    public MenuPrincipal() {
        this.scanner = new Scanner(System.in);
        this.productManager = new ProductManager();
        this.movieManager = new MovieManager();
        this.transactionManager = new TransactionManager();
    }

    public void showMenu() {
        while (true) {
            System.out.println("MENU:");
            System.out.println("1) View products");
            System.out.println("2) Buy product");
            System.out.println("3) Search movie by title");
            System.out.println("4) Search movies by actor");
            System.out.println("5) Exit");
            System.out.print("Optio? ");
            int option = Integer.parseInt(scanner.nextLine());

            switch (option) {
                case 1:
                    viewProducts();
                    break;
                case 2:
                    buyProduct();
                    break;
                case 3:
                    searchMovieByTitle();
                    break;
                case 4:
                    searchMoviesByActor();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void viewProducts() {
        List<Product> products = productManager.getAllProducts();
        System.out.println("STORE");
        for (int i = 0; i < products.size(); i++) {
            Product product = products.get(i);
            System.out.printf("%d - %s - €%.2f\n", i + 1, product.getNom(), product.getPreuVenta());
        }
    }

    private void buyProduct() {
        viewProducts();
        System.out.print("What product? ");
        int productIndex = Integer.parseInt(scanner.nextLine()) - 1;
        System.out.print("Quantity? ");
        int quantity = Integer.parseInt(scanner.nextLine());

        Product product = productManager.getAllProducts().get(productIndex);
        if (product.getQuantitat() >= quantity) {
            productManager.buyProduct(product, quantity);
            transactionManager.addTransaction(new Transaction("Sale", product.getPreuVenta() * quantity));
            System.out.printf("%d %s have been purchased for €%.2f\n", quantity, product.getNom(), product.getPreuVenta() * quantity);
        } else {
            System.out.println("Insufficient stock.");
        }
    }

    private void searchMovieByTitle() {
        System.out.print("Title? ");
        String title = scanner.nextLine();
        Movie movie = movieManager.findMovieByTitle(title);

        if (movie != null) {
            System.out.printf("Title: %s\nRelease date: %s\nSynopsis: %s\n",
                    movie.getTitle(), movie.getReleaseDate(), movie.getOverview());
            System.out.print("Do you want to see the movie (Y/N)? ");
            String response = scanner.nextLine();
            if (response.equalsIgnoreCase("Y")) {
                displayMoviePoster(movie.getPosterPath());
                transactionManager.addTransaction(new Transaction("Watch movie", 5.0));
                System.out.println("A profit of 5 euros has been registered.");
            }
        } else {
            System.out.println("Movie not found.");
        }
    }

    private void displayMoviePoster(String posterPath) {
        try {
            URI uri = new URI("https://www.themoviedb.org/t/p/w300_and_h450_bestv2" + posterPath);
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(uri);
            } else {
                System.out.println("Opening the browser is not supported on this platform.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void searchMoviesByActor() {
        System.out.print("Actor? ");
        String actor = scanner.nextLine();
        List<Movie> movies = movieManager.findMoviesByActor(actor);

        if (!movies.isEmpty()) {
            for (int i = 0; i < movies.size(); i++) {
                Movie movie = movies.get(i);
                System.out.printf("%d) %s\n", i + 1, movie.getTitle());
            }
        } else {
            System.out.println("No movies found for this actor.");
        }
    }
}
