package Bussiness;

import Persistence.UsersDAO;

import java.util.List;

public class UserManager {
    private UsersDAO usersDAO;
    private List<User> users;

    public UserManager() {
        this.usersDAO = new UsersDAO();
        this.users = usersDAO.loadUsers();
        initializeAdmin();
    }

    private void initializeAdmin() {
        if (users.stream().noneMatch(u -> "admin".equals(u.getRole()))) {
            users.add(new User("admin", "password", "admin"));
            usersDAO.saveUsers(users);
        }
    }

    public List<User> getAllUsers() {
        return users;
    }

    public void addUser(User user) {
        users.add(user);
        usersDAO.saveUsers(users);
    }
}
