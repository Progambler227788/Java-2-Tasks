package Bussiness;

public class Product {
    private String nom;
    private double preuCompra;
    private double preuVenta;
    private int quantitat;

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public double getPreuCompra() {
        return preuCompra;
    }

    public void setPreuCompra(double preuCompra) {
        this.preuCompra = preuCompra;
    }

    public double getPreuVenta() {
        return preuVenta;
    }

    public void setPreuVenta(double preuVenta) {
        this.preuVenta = preuVenta;
    }

    public int getQuantitat() {
        return quantitat;
    }

    public void setQuantitat(int quantitat) {
        this.quantitat = quantitat;
    }
}
