package Bussiness;

import Persistence.TransactionsDAO;

import java.util.ArrayList;
import java.util.List;

public class TransactionManager {
    private TransactionsDAO transactionsDAO;
    private List<Transaction> transactions;

    public TransactionManager() {
        this.transactionsDAO = new TransactionsDAO();
        this.transactions = transactionsDAO.loadTransactions();
        if (this.transactions == null) {
            this.transactions = new ArrayList<>();
        }
    }

    public List<Transaction> getAllTransactions() {
        return transactions;
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
        transactionsDAO.saveTransactions(transactions);
    }
}
