package Bussiness;

import Persistence.ProductsDAO;

import java.util.List;

public class ProductManager {
    private ProductsDAO productsDAO;
    private List<Product> products;

    public ProductManager() {
        this.productsDAO = new ProductsDAO();
        this.products = productsDAO.loadProducts();
    }

    public List<Product> getAllProducts() {
        return products;
    }

    public void updateProduct(Product product) {
        productsDAO.saveProducts(products);
    }

    public void buyProduct(Product product, int quantity) {
        product.setQuantitat(product.getQuantitat() - quantity);
        updateProduct(product);
    }
}
