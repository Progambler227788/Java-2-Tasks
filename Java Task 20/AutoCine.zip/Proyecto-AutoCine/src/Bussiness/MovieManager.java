package Bussiness;

import Persistence.MoviesDAO;

import java.util.List;
import java.util.stream.Collectors;

public class MovieManager {
    private MoviesDAO moviesDAO;
    private List<Movie> movies;

    public MovieManager() {
        this.moviesDAO = new MoviesDAO();
        this.movies = moviesDAO.loadMovies();
    }

    public List<Movie> getAllMovies() {
        return movies;
    }

    public void saveMovies(List<Movie> movies) {
        this.movies = movies;
        moviesDAO.saveMovies(movies);
    }

    public Movie findMovieByTitle(String title) {
        return movies.stream()
                .filter(movie -> movie.getTitle().toLowerCase().contains(title.toLowerCase()))
                .findFirst()
                .orElse(null);
    }

    public List<Movie> findMoviesByActor(String actor) {
        return movies.stream()
                .filter(movie -> movie.getCast().stream().anyMatch(c -> c.getName().equalsIgnoreCase(actor)))
                .collect(Collectors.toList());
    }
}
