package spreadsheet;

public abstract class Value extends Content {
    @Override
    public abstract Double getValue();
}
