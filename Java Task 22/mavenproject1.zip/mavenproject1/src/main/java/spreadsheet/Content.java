package spreadsheet;

public abstract class Content {
    public abstract Object getValue();
    @Override
    public abstract String toString();
}
