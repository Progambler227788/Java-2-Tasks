
public class GraphEdge {

//	I need an origin and a destination
//	I need an int type variable
//	and I need a string label
	
	public GraphEdge(GraphNode u, GraphNode v, int type, String label) {
//		I should probably initialize everything
	}
	
//	I should probably fill in the bodies of those setters and getters
	public GraphNode firstEndpoint() {
		
	}
	
	public GraphNode secondEndpoint() {
		
	}
	
	public int getType() {
		
	}
	
	public void setype(int type) {
		
	}
	
	public String getLabel() {
		
	}
	
	public void setLabel(String label) {
		
	}
	
}
