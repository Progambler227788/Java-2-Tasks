
public class GraphNode {

//	I need 2 variables, name and mark
	
	public GraphNode(int name) {
//		It's probably worth it to do something with that name argument
	}

	
//	setters and getters, should be fun
	public void mark(boolean mark) {
		
	}
	
	public boolean isMarked() {
	}
	
	public int getName() {
	}
	
}
