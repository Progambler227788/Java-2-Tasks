import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.text.SimpleDateFormat;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.FileReader;

public class PointsManager {
    private ArrayList<Team> teams;

    public PointsManager() {
        teams = new ArrayList<>();
    }

    public void addTeam(String teamName, ArrayList<String> teamMembers) {
        Team team = new Team(teamName, teamMembers);
        teams.add(team);
        System.out.println("Team " + teamName + " added successfully.");
    }

    public void recordPoints(String teamName, int points) {
        for (Team team : teams) {
            if (team.getName().equals(teamName)) {
                team.addPoints(points);
                return;
            }
        }
        System.out.println("Team not found!");
    }

    public void generateLeaderboardTable() {
        if (teams.isEmpty()) {
            System.out.println("Please add teams first before generating the leaderboard table.");
            System.out.println();
            return;
        }
        sortTeamsByPoints();
        System.out.println("Leaderboard Table");
        System.out.println("------------------------------");
        System.out.println("Team\tPoints");
        System.out.println("------------------------------");
        for (Team team : teams) {
            System.out.println(team.getName() + "\t" + team.getPoints());
        }
        System.out.println();
    }

    public void bookEventForTeam(String teamName, QuizEvent event, SimpleDateFormat dateFormat) {
        for (Team team : teams) {
            if (team.getName().equals(teamName)) {
                team.addBookedEvent(new QuizEvent(teamName, event.getName(), dateFormat.format(event.getDate())));
                System.out.println();
                System.out.println("Event booked successfully for team: " + teamName);
                System.out.println();
                return;
            }
        }
        System.out.println("Team not found!");
    }

    public void sortTeamsByPoints() {
        Collections.sort(teams, new Comparator<Team>() {
            @Override
            public int compare(Team team1, Team team2) {
                return Integer.compare(team2.getPoints(), team1.getPoints());
            }
        });
    }

    public boolean teamExists(String teamName) {
        for (Team team : teams) {
            if (team.getName().equals(teamName)) {
                return true;
            }
        }
        return false;
    }

    public int getTeamCount() {
        return teams.size();
    }

    public String getTeamName(int index) {
        if (index >= 0 && index < teams.size()) {
            return teams.get(index).getName();
        }
        return null;
    }

    public void generateBookingReport(SimpleDateFormat dateFormat) {
        boolean anyBookings = false;
        for (Team team : teams) {
            if (!team.getBookedEvents().isEmpty()) {
                anyBookings = true;
                break;
            }
        }

        if (!anyBookings) {
            System.out.println("There are currently no bookings");
            return;
        }

        System.out.println("Booking Report");
        System.out.println("------------------------------");
        for (Team team : teams) {
            if (!team.getBookedEvents().isEmpty()) {
                System.out.println("Team: " + team.getName());
                System.out.println("Booked Events:");
                for (QuizEvent event : team.getBookedEvents()) {
                    System.out.println("- " + event.getName() + " on " + dateFormat.format(event.getDate()));
                }
                System.out.println("------------------------------");
            }
        }
    }
    // Method to write team data to a file
    public void writeTeamDataToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("teams.txt", false))) {
            for (Team team : teams) {
                writer.println("Team Name: " + team.getName());
                writer.println("Team Members:");
                for (String memberName : team.getMembers()) {
                    writer.println(memberName);
                }
                writer.println("Total Points: " + team.getPoints()); // Write total points for the team
                writer.println(); // Add an empty line between teams
            }
            System.out.println("Team data written to file successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
    
    // Method to read team data from a file
    public void readTeamDataFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("teams.txt"))) {
            String line;
            String teamName = null;
            ArrayList<String> teamMembers = null;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Team Name: ")) {
                    if (teamName != null && teamMembers != null) {
                        // Add the previously read team to the list of teams
                        addTeam(teamName, teamMembers);
                    }
                    // Start reading data for a new team
                    teamName = line.substring("Team Name: ".length());
                    teamMembers = new ArrayList<>();
                } else if (line.equals("Team Members:")) {
                    // Read team members
                    while ((line = reader.readLine()) != null && !line.isEmpty()) {
                        teamMembers.add(line);
                    }
                } else if (line.startsWith("Total Points: ")) {
                    // Read total points for the team
                    int totalPoints = Integer.parseInt(line.substring("Total Points: ".length()));
                    for (Team team : teams) {
                        if (team.getName().equals(teamName)) {
                            team.setPoints(totalPoints);
                            break;
                        }
                    }
                }
            }
            // Add the last team read from the file
            if (teamName != null && teamMembers != null) {
                addTeam(teamName, teamMembers);
            }
            System.out.println("Team data read from file successfully.");
        } catch (IOException e) {
            System.out.println("Error reading from file: " + e.getMessage());
        }
    }

}