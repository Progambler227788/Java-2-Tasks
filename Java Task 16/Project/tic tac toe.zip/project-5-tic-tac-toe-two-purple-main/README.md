[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=15002904)
# Project 5: Tic-Tac-Toe-Two

## Instructions:
1. In IntelliJ IDEA, use New --> Project from Version Control and clone your repository to your local system.
2. Only commit/push from your local environment or terminal, do not use the GitHub interface. Your folder structure must remain intact.
3. Configure your project structure to your JDK version.
4. Perform a commit of the files in your project.
5. Commit whenever your code is in a working state, so you can backtrack to the previous commit if needed.
6. Create a new Swing GUI Designer GUI Form with a linked Bound Class named `ticTacGUI`.
7. Don't implement the GUI yet.
8. Implement the game "Tic Tac Toe" with console interaction. Commit when this is complete, with a descriptive message.
9. Modify your game to "Tic Tac Toe Two" as demonstrated in class. Commit when complete with a descriptive message.
10. Implement the GUI for "Tic Tac Toe Two" using nine JButtons in a JPanel, and ActionListeners.
