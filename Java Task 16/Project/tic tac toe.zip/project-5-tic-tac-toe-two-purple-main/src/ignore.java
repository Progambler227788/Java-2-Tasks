public class ignore {
	public static void main(String[] args) {
		System.out.println("This file is simply to ensure the src directory is committed.\n" +
				"You can delete this file when other files are added to the src directory.");
	}
}
