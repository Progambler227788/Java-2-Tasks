/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pizzabill;

/**
 *
 * @author OCS
 */
public interface PizzaOperations {
    void addextracheese();
    void addextratopping();
    void takeaway();
    void getbill();
   void ExtraOnion();
    void fusionSweettopping();
    void cone();
    
}

