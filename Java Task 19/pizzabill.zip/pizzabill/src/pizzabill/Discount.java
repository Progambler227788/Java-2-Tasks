/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzabill;

/**
 *
 * @author OCS
 */
public class Discount {
      private int totalBill;

    public Discount(int totalBill) {
        this.totalBill = totalBill;
    }

    public int applyDiscount() {
        System.out.println("Applying 10% discount for buying 2 or more pizzas.");
        totalBill = totalBill - (totalBill / 10);
        return totalBill;
    }
}