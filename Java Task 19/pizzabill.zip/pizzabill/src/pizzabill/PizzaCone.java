/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzabill;

/**
 *
 * @author OCS
 */
public class PizzaCone extends Pizza {

    public PizzaCone(Boolean veg, Boolean large) {
        super(veg, large);
        super.cone();
        super.addextratopping();
         orderPizzaCone();
    }
    @Override
    public void cone(){
        
    }
    
    
    @Override
     public void addextratopping(){
        
    }
}
