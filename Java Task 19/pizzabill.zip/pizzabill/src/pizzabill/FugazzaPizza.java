/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzabill;

/**
 *
 * @author OCS
 */
public class FugazzaPizza extends Pizza{

    public FugazzaPizza(Boolean veg, Boolean large) {
        super(veg, large);
        super.addextracheese();
        super.ExtraOnion();
       orderFugazzaPizza();
    }

    @Override
    public void ExtraOnion() {
        
    }

    @Override
    public void addextracheese() {
       
    }
 
}