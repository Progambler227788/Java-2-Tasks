/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pizzabill;


import java.io.File;

import java.io.IOException;
import java.util.Scanner;


/** 
 *
 * @author OCS
 */
public class Pizzabill {

    /**
     * @param args the command line arguments
     */
   
     

    public static void main(String[] args) {
  
       Scanner scanner = new Scanner(System.in);
        boolean continueOrdering = true;

        while (continueOrdering) {
            try {
                int totalBill = 0;
                boolean ordering = true;
                int pizzaCount = 0;

                System.out.println("Welcome to our Pizza Shop!!!!");
                System.out.println("");

                // Collect customer details
                System.out.println("Enter your name: ");
                String name = scanner.nextLine();
                System.out.println("Enter your phone number: ");
                String phone = scanner.nextLine();
                System.out.println("Enter your address: ");
                String address = scanner.nextLine();

                Customer customer = new Customer(name, phone, address);

                System.out.println("Customer Details:");
                System.out.println("Name: " + customer.getName());
                System.out.println("Phone: " + customer.getPhone());
                System.out.println("Address: " + customer.getAddress());
                System.out.println("");

                System.out.println("Choose an option: ");
                System.out.println("1. Order Pizza");
                System.out.println("2. Home Delivery");
                System.out.println("3. Exit");

                int mainChoice = scanner.nextInt();

                if (mainChoice == 3) {
                    continueOrdering = false;
                    break;
                }

                if (mainChoice == 2) {
                    System.out.println("Home Delivery selected. Additional 100 Rs for delivery.");
                    totalBill += 100;
                }

                while (ordering) {
                    System.out.println("Choose an item: ");
                    System.out.println("1. Pizza");
                    System.out.println("2. Side");
                    System.out.println("3. Beverage");
                    System.out.println("4. Exit");

                    int choice = scanner.nextInt();

                    if (choice == 4) {
                        ordering = false;
                        break;
                    }

                    switch (choice) {
                        case 1:
                            if (Pizza.basicPizzaCount <= 0 && Pizza.deluxPizzaCount <= 0 && Pizza.fugazzaPizzaCount <= 0
                                    && Pizza.koreanPizzaCount <= 0 && Pizza.pizzaConeCount <= 0) {
                                System.out.println("Sorry, pizza is not available at the moment.");
                                continue;
                            }

                            System.out.println("Choose a pizza type: ");
                            System.out.println("1. Basic Pizza");
                            System.out.println("2. Deluxe Pizza");
                            System.out.println("3. Fugazza Pizza");
                            System.out.println("4. Korean Pizza");
                            System.out.println("5. Pizza Cone");

                            int pizzaChoice = scanner.nextInt();

                            System.out.println("Is the pizza vegetarian? (true/false): ");
                            boolean veg = scanner.nextBoolean();
                            System.out.println("Is the pizza large? (true/false): ");
                            boolean large = scanner.nextBoolean();

                            Pizza pizza;
                            switch (pizzaChoice) {
                                case 1:
                                    if (Pizza.basicPizzaCount > 0) {
                                        pizza = new Pizza(veg, large);
                                        Pizza.orderBasicPizza(); // Decrement count for basic pizza
                                    } else {
                                        System.out.println("Sorry, Basic Pizza is not available at the moment.");
                                        continue;
                                    }
                                    break;
                                case 2:
                                    if (Pizza.deluxPizzaCount > 0) {
                                        pizza = new DeluxPizza(veg, large);
                                        Pizza.orderDeluxPizza(); // Decrement count for deluxe pizza
                                    } else {
                                        System.out.println("Sorry, Deluxe Pizza is not available at the moment.");
                                        continue;
                                    }
                                    break;
                                case 3:
                                    if (Pizza.fugazzaPizzaCount > 0) {
                                        pizza = new FugazzaPizza(veg, large);
                                        Pizza.orderFugazzaPizza(); // Decrement count for fugazza pizza
                                    } else {
                                        System.out.println("Sorry, Fugazza Pizza is not available at the moment.");
                                        continue;
                                    }
                                    break;
                                case 4:
                                    if (Pizza.koreanPizzaCount > 0) {
                                        pizza = new KoreanPizza(veg, large);
                                        Pizza.orderKoreanPizza(); // Decrement count for korean pizza
                                    } else {
                                        System.out.println("Sorry, Korean Pizza is not available at the moment.");
                                        continue;
                                    }
                                    break;
                                case 5:
                                    if (Pizza.pizzaConeCount > 0) {
                                        pizza = new PizzaCone(veg, large);
                                        Pizza.orderPizzaCone(); // Decrement count for pizza cone
                                    } else {
                                        System.out.println("Sorry, Pizza Cone is not available at the moment.");
                                        continue;
                                    }
                                    break;
                                default:
                                    System.out.println("Invalid choice");
                                    continue;
                            }

                            pizza.getbill();
                            totalBill += pizza.getTotalPrice();
                            pizzaCount++;

                            System.out.println("Pizza Type: " + pizza.getClass().getSimpleName());
                            System.out.println("Vegetarian: " + veg);
                            System.out.println("Large: " + large);
                            System.out.println("Price: " + pizza.getTotalPrice());
                            System.out.println("");
                            break;

                        case 2:
                            System.out.println("Choose a side: ");
                            System.out.println("1. Garlic Bread - 150 Rs");
                            System.out.println("2. Chicken Wings - 250 Rs");
                            System.out.println("3. French Fries - 100 Rs");

                            int sideChoice = scanner.nextInt();

                            SideItems side;
                            switch (sideChoice) {
                                case 1:
                                    side = new SideItems("Garlic Bread", 150);
                                    break;
                                case 2:
                                    side = new SideItems("Chicken Wings", 250);
                                    break;
                                case 3:
                                    side = new SideItems("French Fries", 100);
                                    break;
                                default:
                                    System.out.println("Invalid choice");
                                    continue;
                            }

                            totalBill += side.getPrice();
                            System.out.println("Side: " + side.getName());
                            System.out.println("Price: " + side.getPrice());
                            System.out.println("");
                            break;

                        case 3:
                            System.out.println("Choose a beverage: ");
                            System.out.println("1. Coke - 50 Rs");
                            System.out.println("2. Pepsi - 50 Rs");
                            System.out.println("3. Sprite - 50 Rs");

                            int beverageChoice = scanner.nextInt();

                            Beverage beverage;
                            switch (beverageChoice) {
                                case 1:
                                    beverage = new Beverage("Coke", 50);
                                    break;
                                case 2:
                                    beverage = new Beverage("Pepsi", 50);
                                    break;
                                case 3:
                                    beverage = new Beverage("Sprite", 50);
                                    break;
                                default:
                                    System.out.println("Invalid choice");
                                    continue;
                            }

                            totalBill += beverage.getPrice();
                            System.out.println("Beverage: " + beverage.getName());
                            System.out.println("Price: " + beverage.getPrice());
                            System.out.println("");
                            break;

                        default:
                            System.out.println("Invalid choice");
                            continue;
                    }
                }

                if (pizzaCount >= 2) {
                    Discount discount = new Discount(totalBill);
                    totalBill = discount.applyDiscount();
                }

                System.out.println("Would you like to add a tip? (true/false): ");
                boolean addTip = scanner.nextBoolean();
                if (addTip) {
                    System.out.println("Enter tip amount: ");
                    int tip = scanner.nextInt();
                    totalBill += tip;
                    System.out.println("Tip: " + tip);
                    System.out.println("");
                }

                System.out.println("Total bill: " + totalBill);
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }

            System.out.println("");
            System.out.println("Thanks for using our service!!!");
            System.out.println("Do you want to continue with another customer? (true/false): ");
            continueOrdering = scanner.nextBoolean();
            scanner.nextLine();
        }
    }
}
