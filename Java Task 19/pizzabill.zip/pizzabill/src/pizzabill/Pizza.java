/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pizzabill;

/**
 *
 * @author OCS
 */
public class Pizza implements PizzaOperations {
    protected int price;
    private Boolean veg;
    private Boolean large;
    private int extracheese=100;
    private int extratopping=150;
    private int backpack=50;
    private int extraOnionprice=120;
    private int basepizzaprice;
    private int sweettoppingprice=210;
    private int coneShapeprice=90;
    private Boolean isExtracheeseadded=false;
    private Boolean isExtratoppingadded=false;
    private Boolean isExtraTakeAwayopted=false;
    private Boolean isExtraOnionadded=false;
    private Boolean isExtraSweetToppingadded=false;
    private boolean Coneopted=false;
    public static int basicPizzaCount = 10; 
    public static int deluxPizzaCount = 1; 
    public static int fugazzaPizzaCount = 1; 
    public static int koreanPizzaCount = 10; 
    public static int pizzaConeCount = 10; 
    
    
    Pizza(Boolean veg,Boolean large){
        this.large=large;
        this.veg=veg;
        if(this.veg){
            this.price=500;
        }
        else{
            this.price=1000;
            
        
    }
        if(this.large){
            this.price+=300;
        }
        else{
            this.price-=150;
        }
        basepizzaprice=this.price;
    }
    public void addextracheese(){
        isExtracheeseadded=true;
        
        this.price+=extracheese;
        
        
        
}
    public void addextratopping(){
         isExtratoppingadded=true;
        
        this.price+=extratopping;
    }
    
    public void takeaway(){
        isExtraTakeAwayopted=true;
        
        this.price+=backpack;
        
}
    public void ExtraOnion(){
      isExtraOnionadded=true;
      this.price+=extraOnionprice;
    }
    public void fusionSweettopping(){
        isExtraSweetToppingadded=true;
        this.price+=sweettoppingprice;
    }
    public void cone(){
        Coneopted=true;
        this.price+=coneShapeprice;
        
    }
    public void getbill(){
        String bill="";
        System.out.println("Pizza:"+basepizzaprice);
        if(isExtracheeseadded){
            bill+="Extra cheese added:"+extracheese+"\n";
        }
        if(isExtratoppingadded){
            bill+="Extra topping added:"+extratopping+"\n";
        }
        if(isExtraOnionadded){
            bill+="Extra Onion added:"+extraOnionprice+"\n";
        }
        if(isExtraTakeAwayopted){
            bill+="take away"+backpack+"\n";
        }
        if(isExtraSweetToppingadded){
            bill+="Extra sweet topping added:"+sweettoppingprice+"\n";
        }
        if(Coneopted){
            bill+="Cone shape added:"+coneShapeprice+"\n";
        }
        bill+="bill:"+this.price+"\n";
        System.out.println(bill);
        
    }
    public int getTotalPrice() {
        return this.price;
        
}
    public static void orderBasicPizza() {
        basicPizzaCount--;
    }

    
    public static void orderDeluxPizza() {
        deluxPizzaCount--;
    }

    
    public static void orderFugazzaPizza() {
        fugazzaPizzaCount--;
    }

   
    public static void orderKoreanPizza() {
        koreanPizzaCount--;
    }

    
    public static void orderPizzaCone() {
        pizzaConeCount--;
    }
}

