# Course Registration System
## Table of Contents
- [Description](#description)
- [Technologies Used](#technologies-used)
- [Design Overview](#design-overview)
- [Usage](#usage)
## Description
Our project is an Event Booking System designed to streamline the process of organizing and managing events. It provides functionalities for both administrators and users. Administrators can add, edit, and delete events, while users can view upcoming events, book tickets, and view their booked tickets. The system aims to simplify event management, enhance user experience, and ensure efficient handling of event-related tasks.
## Technologies Used
- **Java**: Core programming language used for building the application logic.
- **JavaFX**: Graphical User Interface (GUI) toolkit for Java used to create the desktop
  application interface.
## Design Overview
The application is structured into several classes, each responsible for specific aspects of the
application:
- **Main**: The entry point of the Event Booking System, which manages the main application loop, user interactions, and file operations.
	- **Variables**: `List<Event> events`, `List<User> users`, `Scanner scanner`, `String USERS_FILE`, `String EVENTS_FILE`
	- **Methods**: `main(String[] args)`, `loadEventsFromFile()`, `saveEventsToFile()`, `loadUsers()`, `saveUsers()`, `handleUserLogin()`, `loadSampleData()`

- **Event**: Represents an individual event with properties such as title, category, description, date/time, location, and capacity.
	- **Variables**: `String title`, `String category`, `String description`, `LocalDateTime dateTime`, `String location`, `int capacity`
	- **Methods**: `Event(String title, String category, String description, LocalDateTime dateTime, String location, int capacity)`, `getTitle()`, `setTitle(String title)`, `getCategory()`, `setCategory(String category)`, `getDescription()`, `setDescription(String description)`, `getDateTime()`, `setDateTime(LocalDateTime dateTime)`, `getLocation()`, `setLocation(String location)`, `getCapacity()`, `setCapacity(int capacity)`, `bookTickets(int numberOfTickets)`, `toString()`

- **Ticket**:Represents a ticket, linking an event, the user, and the quantity of tickets..
	- **Variables**: `Event event`, `User user`, `int quantity`
	- **Methods**: `Ticket(Event event, User user, int quantity)`, `getEvent()`, `setEvent(Event event)`, `getUser()`, `setUser(User user)`, `getQuantity()`, `setQuantity(int quantity)`, `toString()`

- **User**: Represents a user of the system, handling login credentials and ticket management.
	- **Variables**: `String username`, `String password`, `List<Ticket> tickets`
	- **Methods**: `User(String username, String password)`, `addTicket(Ticket ticket)`, `getUsername()`, `setUsername(String username)`, `getPassword()`, `setPassword(String password)`, `getTickets()`, `toString()`, `loadUserTickets()`, `saveUserTickets()`

- **UserScene**: Manages the user interface, enabling users to view events, book tickets, view their tickets, and manage their interactions.
	- **Variables**: `List<Event> events`, `User currentUser`, `Scanner scanner`, `TicketManager ticketManager`
	- **Methods**: `UserScene(List<Event> events, User currentUser, TicketManager ticketManager)`, `displayMenu()`,`viewUpcomingEvents()`, `bookTickets()`, `viewMyTickets()`

- **AdminScene**:  Manages the administrative interface for event management tasks like adding, editing, deleting, and viewing events.
	- **Variables**: `List<Event> events`, `Scanner scanner`
	- **Methods**: `AdminScene(List<Event> events)`, `displayMenu()`, `addEvent()`, `editEvent()`, `deleteEvent()`, `viewEvents()`





## Usage
### Running the Application
To run the application, you will need to have Java and JavaFX set up on your machine. Once
installed, you can compile and run the application from your IDE.
### Using the Application
- **User**
	- 1. **Login**: Start by logging in with your username and password. If you don't have an account, one will be created for you upon your first login.
	- 2. **Viewing Events**: Navigate to the 'Events' section to browse through the available events.
	- 3. **Viewing Your Tickets**: Go to your 'Account' section to see the tickets you have booked. Here, you can also view details about each event for which you've booked tickets.
	- 4. **Booking Tickets**: Click on the event you are interested in and specify the number of tickets you wish to book, then press 'Book'.
	- 5. **Logging Out**: when you are done exit to save changes.
- **Admin**
	- 1. **Login as Admin**:--.
	- 2. **Viewing Events**: Navigate to the 'Events' section to see a list of all current events. This allows you to review all scheduled events.
	- 3. **Adding a New Event**:Click on 'Add Event' to enter details for a new event such as title, category, description, date, location, and capacity. After filling in the information, press 'Save' to add the event to the system.
	- 4. **Editing an Event**:  Select an event from the list and press 'Edit' to update any of the event’s details. Make the necessary changes and click 'Update' to save the edits.
	- 5. **Deleting an Event**: if you need to cancel an event, select the event from the list and press 'Delete'. Confirm the deletion to remove the event from the system.
	- 6. **Logging Out**: When your administrative tasks are complete, log out of the system to secure access and to save changes.	