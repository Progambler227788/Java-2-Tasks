package com.example.demo6;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import java.util.*;

public class AdminScene {

    private static Scanner scanner;
    private static List<Event> events;// Declare the events list
    private List<Event> ttevents;
    private String currentUser;
    private final String USER_DATA_FILE = "admin user.txt";
    private Map<String, String> userCredentials = new HashMap<>();

    public AdminScene() {

        createFileIfNeeded();
        loadUserCredentials();
        events = new ArrayList<>(); // Initialize the events list
    }
    private void createFileIfNeeded() {
        File file = new File(USER_DATA_FILE);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Failed to create new file: " + e.getMessage());
            }
        }
    }

    private void loadUserCredentials() {
        try (BufferedReader reader = new BufferedReader(new FileReader(USER_DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userDetails = line.split(",");
                if (userDetails.length == 2) {
                    userCredentials.put(userDetails[0], userDetails[1]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean registerOrLoginUser(String username, String password) {
        if (userExists(username)) {
            if (validateUser(username, password)) {
                currentUser = username;
                System.out.println("Login successful. Current user set to: " + username);
                return true;
            } else {
                System.out.println("Wrong password for existing user.");
                return false;
            }
        } else {
            addUserToFile(username, password);
            currentUser = username;
            System.out.println("New user registered and logged in. Current user set to: " + username);
            return true;
        }
    }
    private boolean userExists(String username) {
        return userCredentials.containsKey(username);
    }

    private boolean validateUser(String username, String password) {
        return password.equals(userCredentials.get(username));
    }

    private void addUserToFile(String username, String password) {
        try (FileWriter fw = new FileWriter(USER_DATA_FILE, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(username + "," + password);
            userCredentials.put(username, password);
        } catch (IOException e) {
            System.out.println("Error writing to user file.");
        }
    }

    public String getCurrentUser() {
        return currentUser;
    }
    public void addEvent(Event event) {
        events.add(event);
    }
    public AdminScene(List<Event> events) {
        this.events = events;
        this.scanner = new Scanner(System.in);

    }

    public void addEvent(String title, String category, String description, String dateTime, String location, String capacity, String price) {
        LocalDateTime eventDateTime = LocalDateTime.parse(dateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        int eventCapacity = Integer.parseInt(capacity);
        int ticketpr = Integer.parseInt(price);
        Event newEvent = new Event(title, category, description, eventDateTime, location, eventCapacity, ticketpr);
        events.add(newEvent);
        writeEventsToFile(events);
    }
    public static void writeEventsToFile(List<Event> events) {
        try (FileWriter fileWriter = new FileWriter("events.txt", true)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            for (Event event : events) {
                fileWriter.write("Title: " + event.getTitle() + ", ");
                fileWriter.write("Category: " + event.getCategory() + ", ");
                fileWriter.write("Description: " + event.getDescription() + ", ");
                fileWriter.write("Date and Time: " + event.getDateTime().format(formatter) + ", ");
                fileWriter.write("Location: " + event.getLocation() + ", ");
                fileWriter.write("Capacity: " + event.getCapacity() + ", ");
                fileWriter.write("Price: " + event.getPrice() + "\n");
            }

            System.out.println("Events appended to the file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while appending events to the file: " + e.getMessage());
        }
    }
    public static void updateEventsToFile(List<Event> events) {
        try (FileWriter fileWriter = new FileWriter("events.txt", false)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            for (Event event : events) {
                fileWriter.write("Title: " + event.getTitle() + ", ");
                fileWriter.write("Category: " + event.getCategory() + ", ");
                fileWriter.write("Description: " + event.getDescription() + ", ");
                fileWriter.write("Date and Time: " + event.getDateTime().format(formatter) + ", ");
                fileWriter.write("Location: " + event.getLocation() + ", ");
                fileWriter.write("Capacity: " + event.getCapacity() + ", ");
                fileWriter.write("Price: " + event.getPrice() + "\n");
            }

            System.out.println("Events appended to the file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while appending events to the file: " + e.getMessage());
        }
    }
    public static List<Event> readEventsFromFile(String filePath) {
        List<Event> events = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String title = extractValue(line, "Title:");
                String category = extractValue(line, "Category:");
                String description = extractValue(line, "Description:");
                String dateTimeStr = extractValue(line, "Date and Time:");
                String location = extractValue(line, "Location:");
                int capacity = Integer.parseInt(extractValue(line, "Capacity:"));
                int price = Integer.parseInt(extractValue(line, "Price:"));
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                LocalDateTime dateTime = LocalDateTime.parse(dateTimeStr, formatter);
                Event event = new Event(title, category, description, dateTime, location, capacity,price);
                events.add(event);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }

        return events;
    }

    private static String extractValue(String line, String key) {
        int startIndex = line.indexOf(key);
        if (startIndex == -1) {
            System.out.println("Key not found in line: " + key);
            return ""; // Key not found
        }
        startIndex += key.length();
        int endIndex = line.indexOf(",", startIndex); // Find end of value
        if (endIndex == -1) {
            endIndex = line.length(); // If comma not found, take the rest of the line
        }
        String extracted = line.substring(startIndex, endIndex).trim();
        if (extracted.isEmpty()) {
            System.out.println("No value found for key: " + key + " in line: " + line);
        }
        return extracted;
    }


    public static boolean editEventValdtion(String title) {
        events = readEventsFromFile("events.txt");
        for (Event x : events){
            if(x.getTitle().equals(title)){
                return true;
            }
        }
         return false;

    }

    public void editEventsinFile(String title, String category, String description, String dateTime, String location, String capacity,String price) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime eventDateTime = LocalDateTime.parse(dateTime, formatter);

        // Create the edited event object
        Event editedEvent = new Event(title, category, description, eventDateTime, location, Integer.parseInt(capacity), Integer.parseInt(price));

        // Read events from file
        events = readEventsFromFile("events.txt");

        // Check if the event exists
        if (editEventValdtion(editedEvent.getTitle())) {
            for (Event e : events) {
                if (e.getTitle().equals(editedEvent.getTitle())) {
                    // Update event properties
                    e.setCategory(escapeText(e.getCategory(), editedEvent.getCategory()));
                    e.setDescription(escapeText(e.getDescription(), editedEvent.getDescription()));
                    e.setDateTime(eventDateTime);
                    e.setLocation(escapeText(e.getLocation(), editedEvent.getLocation()));
                    e.setCapacity(Integer.parseInt(capacity)); // Update the capacity with the new value
                    e.setPrice(Integer.parseInt(price));
                }
                System.out.println(e);
            }
            // Update events in the file
            updateEventsToFile(events);
        }
    }

    private static String escapeText(String orgText,String newText) {
        if (newText == null || newText.contains(" ")) {
            return orgText;
        }
        return newText ;
    }


    public  boolean deleteEvent(String title) {
        events = readEventsFromFile("events.txt");
        for (Event x : events){
            if(x.getTitle().equals(title)){
                events.remove(x);
                updateEventsToFile(events);

                return true;
            }
        }

        return false;

    }


}
