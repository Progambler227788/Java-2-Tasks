package com.example.demo6;

import java.io.Serializable;

public class Ticket implements Serializable {
    private String title;
    private String user;
    private int quantity;
    private int totalCost;

    // Updated constructor with totalCost as a parameter
    public Ticket(String user, String title, int quantity, int totalCost) {
        this.title = title;
        this.user = user;
        this.quantity = quantity;
        this.totalCost = totalCost;
    }

    // Getters (add these if not already present to help with data access)
    public String getTitle() {
        return title;
    }

    public String getUser() {
        return user;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getTotalCost() {
        return totalCost;
    }

    // Setters (optional, add these if you need to modify the fields after object creation)
    public void setTitle(String title) {
        this.title = title;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setTotalCost(int totalCost) {
        this.totalCost = totalCost;
    }
}
