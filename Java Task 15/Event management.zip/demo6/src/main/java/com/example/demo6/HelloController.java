package com.example.demo6;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ResourceBundle;
import java.net.URL;
import java.util.ResourceBundle;

import static com.example.demo6.AdminScene.writeEventsToFile;

/**
 * JavaFX App
 */
public class HelloController extends Application {

    private static Scene scene1;
    @FXML
    private Button adminButton;

    @FXML
    private Button userButton;
    @FXML
    private Button saveButton;


    private static String username;

    public static void setUsername(String username) {
        HelloController.username = username;
    }



    @FXML
    private void adminButtonClicked(ActionEvent event) throws IOException {
        // Load the AdminPage.fxml file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("admin-page.fxml"));
        Parent adminPageParent = loader.load();
        AdminPage controller = loader.getController();
        controller.setUsername(username); // Pass the username to the next scene

        Scene adminPageScene = new Scene(adminPageParent);

        // Get the stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        // Set the AdminPage scene onto the stage
        window.setScene(adminPageScene);
        window.show();
    }

    @FXML
    private void userButtonClicked(ActionEvent event) throws IOException {
        // Load the UserPage.fxml file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("user-page.fxml"));
        Parent userPageParent = loader.load();
        UserPage controller = loader.getController();
        controller.setUsername(username); // Pass the username to the next scene

        Scene userPageScene = new Scene(userPageParent);

        // Get the stage information
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();

        // Set the UserPage scene onto the stage
        window.setScene(userPageScene);
        window.show();
    }

    @Override
    public void start(Stage stage) throws IOException {
        scene1 = new Scene(loadFXML("hello-view"));
        stage.setScene(scene1);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException { //To change the pages after clicking a button
        scene1.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloController.class.getResource(fxml + ".fxml"));
        Parent root = fxmlLoader.load();
        return root;
    }

    public static void main(String[] args) {
        launch();
    }

}
