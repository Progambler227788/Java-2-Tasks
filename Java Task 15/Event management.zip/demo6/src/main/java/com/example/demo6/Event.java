package com.example.demo6;

import java.time.LocalDateTime;
import java.io.Serializable;

public class Event implements Serializable {
    private String title;
    private String category;
    private String description;
    private LocalDateTime dateTime;
    private String location;
    private int capacity;
    private int price;

    // Constructor
    public Event(String title, String category, String description, LocalDateTime dateTime, String location, int capacity, int price) {
        this.title = title;
        this.category = category;
        this.description = description;
        this.dateTime = dateTime;
        this.location = location;
        this.capacity = capacity;
        this.price = price;
    }

    // Getters and Setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    // Method to reduce the capacity when a ticket is booked
    public boolean bookTickets(int numberOfTickets) {
        if (this.capacity >= numberOfTickets) {
            this.capacity -= numberOfTickets;
            return true; // Booking successful
        }
        return false; // Booking unsuccessful due to insufficient capacity
    }
//    public static void writeeEventsToFile(List<Event> events) {
//        System.out.println("eee");
//        try (FileWriter fileWriter = new FileWriter("events.txt")) {
//            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
//            System.out.println("Ddd");
//
//            for (Event event : events) {
//                fileWriter.write("Title: " + event.getTitle() + "\n");
//
//            }
//
//            System.out.println("Events written to the file successfully.");
//        } catch (IOException e) {
//            System.out.println("An error occurred while writing events to the file: " + e.getMessage());
//        }
//    }

    @Override
    public String toString() {
        return "Event{" +
                "title='" + title + '\'' +
                ", category='" + category + '\'' +
                ", description='" + description + '\'' +
                ", Date and Time=" + dateTime +
                ", location='" + location + '\'' +
                ", capacity=" + capacity +
                ", price=" + price +
                '}';
    }
}

