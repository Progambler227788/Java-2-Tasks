package com.example.demo6;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import javafx.event.ActionEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import static com.example.demo6.UserScene.readTicketsFromFile;

public class UserPage implements Initializable{

    UserScene user;
    private List<Event> events ;

    @FXML
    private Button enter;
    @FXML
    private TextField usernameField;
    @FXML
    private  TextField passwordField;
    @FXML
    private AnchorPane welcomePage;
    @FXML
    private AnchorPane mainPage;
    @FXML
    private AnchorPane TableP;

    @FXML
    private AnchorPane Bookp;
    @FXML
    private AnchorPane tableticket;
    @FXML
    private Label welcomeLAbel;
    @FXML
    private  Button backbutton;
    private UserScene userScene = new UserScene();
    private String currentUser;
    private String username; // Add this field

    public void setUsername(String username) {
        this.username = username;
    }
    @FXML
    private Label wronnguser;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        user=new UserScene();
        mainPage.setVisible(false);
        welcomePage.setVisible(true);
    }

    @FXML
    void enterAct() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        if (username.isEmpty() || password.isEmpty()) {
            wronnguser.setText("Username and password cannot be empty.");
            return;
        }
        if (userScene.registerOrLoginUser(username, password)) { // This method internally handles user existence checks and validations
            wronnguser.setText("Login successful.");
            welcomePage.setVisible(false);
            mainPage.setVisible(true);  // Make the main page visible
            welcomeLAbel.setText("Welcome " + username + "!");
            user = userScene; // Set the user instance to the one managing the current user state
        } else {
            wronnguser.setText("Invalid username or password.");
        }
        if (userScene.validateUser(username, password)) {
            wronnguser.setText("Login successful.");
            welcomePage.setVisible(false);
            mainPage.setVisible(true);  // Make the main page visible
            welcomeLAbel.setText("Welcome "+usernameField.getText().toString()+" !");
        } else {
            wronnguser.setText("Invalid username or password.");
        }


        userScene.registerOrLoginUser(username, password);
    }


    @FXML
    private TableView<Event> viewTable;
    @FXML
    private TableColumn<Event, String> titleCol1;
    @FXML
    private TableColumn<Event, String> categoryCol2;
    @FXML
    private TableColumn<Event, String> descCol3;
    @FXML
    private TableColumn<Event, LocalDateTime> dateCol4;
    @FXML
    private TableColumn<Event, String> locaCol5;
    @FXML
    private TableColumn<Event, Integer> capaCol6;
    @FXML
    private  TableColumn<Event, Integer> pricecol;

    @FXML
    private Button viewUP;
    @FXML
    private Button viewBookedTickets;

    @FXML
    void viewupAct(ActionEvent e){
        table();
        Bookp.setVisible(false);
        TableP.setVisible(true);
        tableticket.setVisible(false);

    }

    public void table(){
        events = user.readEventsFromFile("events.txt"); // Read the latest events
        viewTable.getItems().clear(); // Clear existing data
        viewTable.getItems().addAll(events); // Add new data

        // Ensure columns are mapped correctly
        titleCol1.setCellValueFactory(new PropertyValueFactory<>("title"));
        categoryCol2.setCellValueFactory(new PropertyValueFactory<>("category"));
        descCol3.setCellValueFactory(new PropertyValueFactory<>("description"));
        dateCol4.setCellValueFactory(new PropertyValueFactory<>("dateTime"));
        locaCol5.setCellValueFactory(new PropertyValueFactory<>("location"));
        capaCol6.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        pricecol.setCellValueFactory(new PropertyValueFactory<>("price"));
    }


    @FXML
    private Button bookButton;
    @FXML
    private Button confBook;
    @FXML
    private TextField numOfTickets;
    @FXML
    private TextField titleToBook;
    @FXML
    private Label WrongBook;
    @FXML
    void swichPage(ActionEvent event) {
        if (event.getSource() == viewUP) {
            table();
            TableP.setVisible(true);
            Bookp.setVisible(false);
        }

        else if (event.getSource() == bookButton) {
        TableP.setVisible(false);
        Bookp.setVisible(true);
tableticket.setVisible(false);



    }


    }
    public void login(String username, String password) {
        if (userScene.validateUser(username, password)) {
            currentUser = username; // Set the current user
            userScene.setCurrentUser(currentUser); // Pass it to UserScene
            enterAct(); // Proceed with showing the main page
        }
    }

    @FXML
    void book(ActionEvent event) {
        if (user == null) {
            WrongBook.setText("User not initialized or not logged in.");
            return;
        }

        try {
            String title = titleToBook.getText().trim();
            String numOfTicketsStr = numOfTickets.getText().trim();

            int numOfTickets = Integer.parseInt(numOfTicketsStr);

            if (userScene.bookTickets(title, numOfTickets, currentUser)) {
                WrongBook.setText("Tickets booked successfully for " + title);
                viewTable.refresh(); // Refresh the table to show updated event capacities
            } else {
                WrongBook.setText("Failed to book tickets or insufficient capacity.");
            }

        } catch (NumberFormatException e) {
            WrongBook.setText("Invalid number of tickets entered. Please enter a valid integer.");
        }
    }






    @FXML
    private TableView<Ticket> ticketTable;
    @FXML
    private TableColumn<Ticket, String> eventColumn;
    @FXML
    private TableColumn<Ticket, Integer> numTicketsColumn;
    @FXML
    private TableColumn<Ticket, Integer> totalCostColumn;
@FXML
    void viewBookedTickets(ActionEvent event) {
    setUsername(username);
    System.out.println(username);
        TableP.setVisible(false);
        Bookp.setVisible(false);
        tableticket.setVisible(true);
        loadUserTickets();  // Load and show tickets for the current user
    }

    public void loadUserTickets() {
        String username = usernameField.getText().trim();
        System.out.println(username);
        setUsername(username);
        File ticketFile = new File("tickets_" + username + ".txt");
        List<Ticket> tickets = new ArrayList<>();

        try (Scanner scanner = new Scanner(ticketFile)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                Map<String, String> ticketMap = parseTicketLine(line);

                String event = ticketMap.get("Event");
                int numTickets = (Integer.parseInt(ticketMap.get("Tickets")));
                int totalCost = Integer.parseInt(ticketMap.get("Total Cost").replace("$", "").trim());

                // Assuming a Ticket constructor that takes event, numTickets, and totalCost
                Ticket ticket = new Ticket(username,event, numTickets, totalCost);
                tickets.add(ticket);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Ticket file not found for user: " + username);
            return;
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            System.out.println("Error parsing ticket data: " + e.getMessage());
            return;
        }

        // Clear existing data
        ticketTable.getItems().clear();
        // Add new data
        ticketTable.getItems().addAll(tickets);

        // Ensure columns are mapped correctly
        eventColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        numTicketsColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        totalCostColumn.setCellValueFactory(new PropertyValueFactory<>("totalCost"));
    }

    private Map<String, String> parseTicketLine(String line) {
        Map<String, String> ticketMap = new HashMap<>();

        // Example line format: "Event: New Event, Tickets: 10, Total Cost: $1000"
        String[] parts = line.split(",");  // Splitting by comma for each part

        for (String part : parts) {
            String[] keyValue = part.split(":");  // Splitting by colon to separate key and value
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();
                ticketMap.put(key, value);
            }
        }

        return ticketMap;
    }




    @FXML
    void back(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Get the stage from the action event source
            Stage stage = (Stage) backbutton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
