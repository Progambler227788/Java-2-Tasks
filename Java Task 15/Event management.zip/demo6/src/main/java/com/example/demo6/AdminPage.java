package com.example.demo6;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class AdminPage implements Initializable {
    AdminScene admin ;
    private List<Event> events ;
    @FXML
    private AnchorPane addPage;
    @FXML
    private AnchorPane editPage;
    @FXML
    private  Button backbutton;
    @FXML
    private AnchorPane deletePage;
    @FXML
    private AnchorPane viewPage;
    @FXML
    private Button addButton;
    @FXML
    private Button editButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button viewButton;
    @FXML
    private Button returnButton;
    @FXML
    private TextField usernameField;
    @FXML
    private  TextField passwordField;
    @FXML
    private AnchorPane welcomePage;
    @FXML
    private AnchorPane mainPage;
    @FXML
    private Label wrongUserLabel;
    private String username; // Add this field

    public void setUsername(String username) {
        this.username = username;
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        admin = new AdminScene();
        welcomePage.setVisible(true);
        mainPage.setVisible(false);
    }
    @FXML
    private void enterAct() {
        AdminScene auth = new AdminScene();
        String username = usernameField.getText();
        String password = passwordField.getText();

        boolean loginSuccessful = auth.registerOrLoginUser(username, password);
        if (loginSuccessful) {
            welcomePage.setVisible(false); // Hide the welcome pane
            mainPage.setVisible(true);     // Show the main pane
            wrongUserLabel.setText("Login successful!");
        } else {
            wrongUserLabel.setText("Login failed. Please check your credentials.");
        }
    }

    //////////////////// Switch Pages /////////////////////
    @FXML
    void swichPage(ActionEvent event) {
        if (event.getSource() == addButton) {
            addPage.setVisible(true);
            deletePage.setVisible(false);
            editPage.setVisible(false);
            viewPage.setVisible(false);
        } else if (event.getSource() == editButton) {
            addPage.setVisible(false);
            editPage.setVisible(true);
            deletePage.setVisible(false);
            viewPage.setVisible(false);
        } else if (event.getSource() == deleteButton) {
            deletePage.setVisible(true);
            addPage.setVisible(false);
            editPage.setVisible(false);
            viewPage.setVisible(false);
        } else if (event.getSource() == viewButton) {
            table();
            addPage.setVisible(false);
            editPage.setVisible(false);
            viewPage.setVisible(true);
            deletePage.setVisible(false);
        }
    }

    ////////////// page 1 (add) //////////////
    @FXML
    private TextField title;
    @FXML
    private TextField caregory;
    @FXML
    private TextField descreption;
    @FXML
    private TextField date;
    @FXML
    private TextField location;
    @FXML
    private TextField capacity;
    @FXML
    private TextField ticketprice;
    @FXML
    private Button submitButton;

    @FXML
    void submitEvent(ActionEvent event) {

        String title1 = title.getText().toString();
        String category = caregory.getText().toString();
        String description = descreption.getText().toString();
        String dateTime = date.getText().toString();
        String location1 = location.getText().toString();
        String capacityStr = capacity.getText().toString();
        String ticketpriceStr = ticketprice.getText().toString();
        // Perform validation checks
        if (title1.isEmpty() || category.isEmpty() || description.isEmpty() || dateTime.isEmpty() ||
                location1.isEmpty() || capacityStr.isEmpty()) {
            System.out.println("Please fill in all fields.");
            return;
        }


        try {
            int capacity = Integer.parseInt(capacityStr);



            admin.addEvent(title1, category, description, dateTime, location1, capacityStr,ticketpriceStr);


            System.out.println("aa");

        } catch (NumberFormatException e) {
            System.out.println("Invalid capacity input. Please enter a valid integer value.");
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date and time format. Please enter a valid format (yyyy-MM-dd HH:mm).");
        }
    }

    /////////////////// View ALL Page ////////////////////

    @FXML
    private TableView<Event> viewAllTable;
    @FXML
    private TableColumn<Event, String> titleCol;
    @FXML
    private TableColumn<Event, String> categoryCol;
    @FXML
    private TableColumn<Event, String> descCol;
    @FXML
    private TableColumn<Event, LocalDateTime> dateCol;
    @FXML
    private TableColumn<Event, String> locaCol;
    @FXML
    private TableColumn<Event, Integer> capaCol;
   @FXML
   private  TableColumn<Event, String> pricecol;



    public void table(){
        System.out.println("Fsf");
        addPage.setVisible(false);
        editPage.setVisible(false);
        viewPage.setVisible(true);
        deletePage.setVisible(false);
        events = admin.readEventsFromFile("events.txt");
        viewAllTable.getItems().clear();
        viewAllTable.getItems().addAll(events);
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        descCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("dateTime"));
        locaCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        capaCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        pricecol.setCellValueFactory(new PropertyValueFactory<>("price"));
        capaCol.setCellFactory(column -> new TableCell<Event, Integer>() {
            @Override
            protected void updateItem(Integer capacity, boolean empty) {
                super.updateItem(capacity, empty);
                if (empty || capacity == null) {
                    setText("");
                } else {
                    setText(String.valueOf(capacity));
                }
            }
        });}

        ////////////// Edit /////////////
    @FXML
    private Button checkButton;

    @FXML
    private TextField titleToEdit;
    @FXML
    private Label wrongTitle;

//    public void edit() {
//        if (admin.editEvent(titleToEdit.getText().toString())==true){
//            wrongTitle.setText("Wee");
//        }
//        else {
//            wrongTitle.setText("wroinf");
//        }
//
//    }

    @FXML
    private TextField category1;
    @FXML
    private TextField descreption1;
    @FXML
    private TextField date1;
    @FXML
    private TextField location1;
    @FXML
    private TextField capacity1;
    @FXML
    private TextField ticketprice1;
    @FXML
    void checkevent(ActionEvent event){
        if (admin.editEventValdtion(titleToEdit.getText().toString())==true){
            wrongTitle.setText("Valid title!");
        }
        else {
            wrongTitle.setText("Wrong title!");
        }
    }
    @FXML
    private Button submitb;
    @FXML
    void sumbitedited(ActionEvent c){
        String title11 = titleToEdit.getText().toString();
        String category11 = category1.getText().toString();
        String description11 = descreption1.getText().toString();
        String dateTime11 = date1.getText().toString();
        String location11 = location1.getText().toString();
        String capacityStr11 = capacity1.getText().toString();
        String ticketpriceStr1 = ticketprice1.getText().toString();
        /////Title: dcad, Category: dcs, Description: cascd, Date and Time: 2024-12-12 12:12, Location: fefe, Capacity: 33

        admin.editEventsinFile(title11,category11,description11,dateTime11,location11,capacityStr11,ticketpriceStr1);

    }
    //// Delete
    @FXML
    private Label deleteLabel ;

    @FXML
    private TextField titleTodelete ;
    @FXML
    private Button deleteButtonn;

    @FXML
    void ButtonAct(ActionEvent s){
       if(admin.deleteEvent(titleTodelete.getText().toString())){
           deleteLabel.setText("Event deleted successfully!");
       }
       else {
           deleteLabel.setText("Event not found!");

       }


    }
    /// Back Button
    @FXML
    void back(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Get the stage from the action event source
            Stage stage = (Stage) backbutton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}


