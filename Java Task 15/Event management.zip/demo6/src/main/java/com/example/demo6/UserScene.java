package com.example.demo6;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserScene {
    private List<Event> events;
    private String currentUser;
    private List<String> titles;

    private Scanner scanner;
    private List<Ticket> tickets;
    private List<UserScene> userss;


    public UserScene() {


    }

    public UserScene(String currentUser, List<String> titles) {
        this.currentUser = currentUser;
        this.titles = titles;

    }


    public static void main(String[] args) {
        System.out.println();
        Ticket t = new Ticket("X", "eded", 5,200);
        List<Ticket> ts = new ArrayList<>();
        ts.add(t);
        writeUserTicketsToFile("Joe", "Concert Music Extravaganza", 14, 200);


    }

    public static List<UserScene> readUserFromFile(String filePath) {
        List<UserScene> users = new ArrayList<>();


        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                if (data.length >= 2) {
                    String username = data[0].trim();
                    List<String> titles = new ArrayList<>();
                    for (int i = 1; i < data.length; i++) {
                        titles.add(data[i].trim());
                    }
                    UserScene user = new UserScene(username, titles);
                    users.add(user);
                }

            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }

        return users;
    }

    private static final String USERS_FILE_PATH = "users.txt";

    public boolean validateUser(String username, String password) {
        try (Scanner scanner = new Scanner(new File(USERS_FILE_PATH))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                if (data.length >= 2 && data[0].trim().equals(username)) {
                    return data[1].trim().equals(password);  // Check password
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while validating user: " + e.getMessage());
        }
        return false; // User not found or error occurred
    }

    public boolean registerOrLoginUser(String username, String password) {
        if (userExists(username)) {
            if (validateUser(username, password)) {
                this.currentUser = username;
                System.out.println("Login successful. Current user set to: " + username);
            } else {
                System.out.println("Wrong password for existing user.");
            }
        } else {
            addUserToFile(username, password);
            this.currentUser = username;
            System.out.println("New user registered and logged in. Current user set to: " + username);
        }
        return false;
    }



    public void addUserToFile(String username, String password) {
        if (!userExists(username)) {
            try (FileWriter fileWriter = new FileWriter(USERS_FILE_PATH, true)) {
                fileWriter.write(username + "," + password + "\n");
            } catch (IOException e) {
                System.out.println("An error occurred while adding the user: " + e.getMessage());
            }
        }
    }

    private boolean userExists(String username) {
        try (Scanner scanner = new Scanner(new File(USERS_FILE_PATH))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                if (data.length >= 2 && data[0].trim().equals(username)) {
                    return true; // User already exists
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while checking if the user exists: " + e.getMessage());
        }
        return false; // User does not exist
    }

    public boolean valdtion(String usernameStr, String enteredPassword) {

        for (UserScene x : readUserFromFile("users.txt")) {
            if (x.getCurrentUser().equals(usernameStr)) {
                return true;
            }
        }
        return false;
    }

    public static List<Event> readEventsFromFile(String filePath) {
        List<Event> events = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("File does not exist: " + filePath);
            return events;  // Return an empty list if file does not exist
        }

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                try {
                    String line = scanner.nextLine();
                    String title = extractValue(line, "Title:");
                    String category = extractValue(line, "Category:");
                    String description = extractValue(line, "Description:");
                    String dateTimeStr = extractValue(line, "Date and Time:");
                    String location = extractValue(line, "Location:");
                    int capacity = Integer.parseInt(extractValue(line, "Capacity:"));
                    int price = Integer.parseInt(extractValue(line,"Price:"));

                    LocalDateTime dateTime = LocalDateTime.parse(dateTimeStr, formatter);
                    Event event = new Event(title, category, description, dateTime, location, capacity, price);
                    events.add(event);

                } catch (DateTimeParseException | NumberFormatException e) {
                    System.out.println("Error parsing line: " + e.getMessage());

                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Unexpected error: File not found after existence check: " + e.getMessage());
        }

        System.out.println("Total events loaded: " + events.size());
        return events;
    }

    private static String extractValue(String line, String key) {
        int startIndex = line.indexOf(key);
        if (startIndex == -1) {
            return ""; // Key not found
        }
        startIndex += key.length();
        int endIndex = line.indexOf(",", startIndex); // Find end of value
        if (endIndex == -1) {
            endIndex = line.length(); // If comma not found, take the rest of the line
        }
        return line.substring(startIndex, endIndex).trim();
    }

    public static List<Ticket> readTicketsFromFile(String filePath) {
        List<Ticket> tickets = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(filePath))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                if (data.length >= 3) {
                    String username = data[0].trim();
                    String event = data[1].trim();
                    int numOfTickets = Integer.parseInt(data[2].trim());
                    int totalcost= 0;
                    Ticket ticket = new Ticket(username, event, numOfTickets,totalcost);
                    tickets.add(ticket);
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }

        return tickets;
    }

    public boolean bookTickets(String title, int numOfTickets, String currentUser) {
        List<Event> events = readEventsFromFile("events.txt");
        for (Event e : events) {
            if (title.equals(e.getTitle()) && e.getCapacity() >= numOfTickets) {
                int newCapacity = e.getCapacity() - numOfTickets;
                e.setCapacity(newCapacity);
                int totalCost = numOfTickets * e.getPrice();
                writeEventsToFile(events); // Update the events file with the new capacity
                writeUserTicketsToFile(this.currentUser, title, numOfTickets, totalCost); // Include total cost here

                System.out.println(this.currentUser);
                return true;
            }
        }
        return false; // Booking failed
    }





    private static void writeUserTicketsToFile(String currentUser, String eventTitle, int ticketsBooked, int totalCost) {
        if (currentUser == null || currentUser.isEmpty()) {
            System.out.println("Error: Current user is not set or empty.");
            return; // or throw an exception
        }

        String filename = "tickets_" + currentUser + ".txt"; // User-specific file
        File file = new File(filename);

        try (FileWriter writer = new FileWriter(file, true)) { // true to append to the file
            writer.write("Event: " + eventTitle + ", Tickets: " + ticketsBooked + ", Total Cost: $" + totalCost + "\n");
            System.out.println("Ticket booked successfully for " + ticketsBooked + " tickets to " + eventTitle + ", costing a total of $" + totalCost + " and written to " + filename);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the user's ticket file: " + e.getMessage());
            // Consider retrying or escalating the error
        }
    }






    public static void writeEventsToFile(List<Event> events) {
        try (FileWriter fileWriter = new FileWriter("events.txt", false)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            for (Event event : events) {
                fileWriter.write("Title: " + event.getTitle() + ", ");
                fileWriter.write("Category: " + event.getCategory() + ", ");
                fileWriter.write("Description: " + event.getDescription() + ", ");
                fileWriter.write("Date and Time: " + event.getDateTime().format(formatter) + ", ");
                fileWriter.write("Location: " + event.getLocation() + ", ");
                fileWriter.write("Capacity: " + event.getCapacity() + ", ");
                fileWriter.write("Price: " + event.getPrice() + "\n");
            }

            System.out.println("Events appended to the file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while appending events to the file: " + e.getMessage());
        }
    }


    public String getCurrentUser(){
        return currentUser;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + currentUser.substring(0) + '\'' +
                ", tickets=" +  +
                '}';
    }

    public void setCurrentUser(String currentUser) {
        this.currentUser = currentUser;
    }

}

