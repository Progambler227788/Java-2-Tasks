package palindrome;

// import libraries to be used in code
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.Scanner;

public class PalindromeChecker {
    private String inputString;
    
    // Constructor to strore input string
    public PalindromeChecker(String inputString) {
        this.inputString = inputString;
    }
    
    // Function to remove Spaces and Punctuations from user input string
    public String removeSpacesAndPunctuation(String input) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
        	// If a character is letter then append otherwise ignore
            if (Character.isLetter(c)) {
            	// append mean at the end of result StringBuilder variable
                result.append(c);
            }
        }
        // Convert result to string and user lower case strings
        return result.toString().toLowerCase();
    }

    // Function to check palindrome
    public boolean isPalindrome() {
        // Clean the input string by removing spaces and punctuation and converting to lowercase
        String cleanedString = removeSpacesAndPunctuation(inputString);

        // Create a stack and a queue
        Stack<Character> stack = new Stack<>();
        Queue<Character> queue = new LinkedList<>();

        // Push each letter onto the stack and enqueue onto the queue
        for (int i = 0; i < cleanedString.length(); i++) {
            char c = cleanedString.charAt(i);
            stack.push(c);
            queue.offer(c);
        }
        // For example user string is, abc
        // Stack will be like that cba, at top there will be c because of LIFO (last in first out)
        // Que will be like that abc, at top there will be a because of FIFO (first in first out)
        
        // So, we have to pop characters from stack and queue same time to verify
        // that they are same because as we know if read Palindrome either from start or end gives same word

        // Pop from the stack and dequeue from the queue and compare the letters
        while (!stack.isEmpty() && !queue.isEmpty()) {
            if (stack.pop() != queue.poll()) {
                return false; // If letters don't match, it's not a palindrome
            }
        }

        return true; // If all letters match, it's a palindrome
    }

    public static void main(String[] args) {
     
    	Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a string
        System.out.print("Enter characters: ");
        // store user input in variable
        String userInput = scanner.nextLine();

        // Create a PalindromeChecker object with user input
        PalindromeChecker checker = new PalindromeChecker(userInput);

        // Check if the input string is a palindrome and print the result
        System.out.println("Is it a palindrome? " + checker.isPalindrome());

        scanner.close();
    }
}
// End of PalindromeChecker Class

