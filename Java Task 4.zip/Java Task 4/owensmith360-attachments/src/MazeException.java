public class MazeException extends Exception {
  public MazeException(String mssg) {
    super(mssg);
  }
}
